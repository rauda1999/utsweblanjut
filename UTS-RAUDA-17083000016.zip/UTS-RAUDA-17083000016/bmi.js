const express = require("express");
const bodyparser = require("body-parser");

const app = express();
app.use(bodyparser.urlencoded({ extended: true }));
app.use('/css', express.static(__dirname + '/node_modules/bootstrap/dist/css'));
app.use('/js', express.static(__dirname + '/node_modules/bootstrap/dist/js'));

app.get("/bmicalculator", function (req, res) {
    res.sendFile(__dirname + "/coding.html");
});

app.post("/bmicalculator", function (req, res) {
    height = parseFloat(req.body.height);
    weight = parseFloat(req.body.weight);
    bmi = weight / (height * height);

    bmi = bmi.toFixed();
  
    req_name = req.body.name;

    if (bmi < 19) {
        res.send("<h3>Hey! " + req_name +
                 " Your BMI is around: " + bmi +
                 "<centre><h1>You are malnourished, eat enough!");
    } else if (19 <= bmi && bmi < 25) {
        res.send("<h3>Yeay! " + req_name +
                 " Your BMI is around: " + bmi +
                 "<centre><h1>You have enough nutrition, keep eating healthy foods!");
    } else if (25 <= bmi && bmi < 30) {
        res.send("<h3>Oops! " + req_name +
                 " Your BMI is around: " + bmi +
                 "<centre><h1>You are ove-nourished, mantain a diet, get adequet rest, and exercise regularly!");
    } else {
        res.send("<h3>Dangerous! " + req_name +
                 " Your BMI is around: " + bmi +
                 "<centre><h1>It's dangerous you are obese, eat less fatty foods and get enough sleep!");
    }
});

app.listen(3000, function () {
    console.log("Successfully connected to port 3000");
});